## Nukkit Bug Report

(DO NOT OPEN A ISSUE IF THIS IS A PLUGIN ERROR)

PLUGIN ERROR: TRUE

### Issue Description
<!--- Use our forum https://forums.nukkit.io for questions -->
??

### Steps to Reproduce the Issue
<!--- Help us to find the problem by adding steps to reproduce the issue -->
??

### OS and Versions
* Nukkit Version: 1.0dev 
* Git Commit Abbrev: b7f73ab
* Java Version: 
```
Java HotSpot(TM) Client VM (1.8.0_65-b17)
```

* Host Configuration: 


| Item | Value |
|:----:|:-----:|
| Host OS | Raspbian GNU/Linux [8] |  
| Memory(RAM) | 968.2 MB | 
| Storage Size | 31.9 GB | 
| Storage Type | Unknown  | 
| CPU Type | ARMv7 Processor rev 4 (v7l) | 
| CPU Core Count | 1 cores 4 threads | 
| Upstream Bandwidth | ?? | 

* Client Configuration: 

| Item | Value |
|:----:|:-----:|
| Client Edition | ?? | 
| Client Version | ?? | 

### Crashdump, Backtrace or Other Files

```
java.lang.StringIndexOutOfBoundsException: String index out of range: 2
	at java.lang.AbstractStringBuilder.charAt(AbstractStringBuilder.java:210)
	at java.lang.StringBuilder.charAt(StringBuilder.java:76)
	at jline.console.ConsoleReader.wcwidth(ConsoleReader.java:555)
	at jline.console.ConsoleReader.backspace(ConsoleReader.java:1057)
	at jline.console.ConsoleReader.backspaceAll(ConsoleReader.java:1043)
	at jline.console.ConsoleReader.resetPromptLine(ConsoleReader.java:3858)
	at cn.nukkit.command.CommandReader.removePromptLine(CommandReader.java:120)
	at cn.nukkit.Nukkit.main(Nukkit.java:93)

```