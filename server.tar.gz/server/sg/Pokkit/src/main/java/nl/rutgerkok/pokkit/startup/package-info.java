/**
 * The only package that contains classes stored in Pokkit.jar, but loaded by
 * the Nukkit class loader.
 *
 */
package nl.rutgerkok.pokkit.startup;