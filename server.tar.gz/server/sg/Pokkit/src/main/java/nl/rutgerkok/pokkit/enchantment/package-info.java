/**
 * Enchantments: applied to tools and armor to make them stronger.
 */
package nl.rutgerkok.pokkit.enchantment;