/**
 * Implementations of BlockState.
 *
 */
package nl.rutgerkok.pokkit.blockstate;