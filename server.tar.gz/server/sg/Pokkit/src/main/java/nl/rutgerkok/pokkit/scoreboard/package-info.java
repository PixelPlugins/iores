/**
 * Scoreboard system. Unfortunately, scoreboards are not displayed in PE.
 *
 */
package nl.rutgerkok.pokkit.scoreboard;
