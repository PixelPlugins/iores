/**
 * Classes relating to permissions.
 */
package nl.rutgerkok.pokkit.permission;