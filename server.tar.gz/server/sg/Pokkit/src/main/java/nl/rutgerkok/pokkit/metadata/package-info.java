/**
 * Classes relati
 */
package nl.rutgerkok.pokkit.metadata;