/**
 * Classes dealing with players.
 *
 */
package nl.rutgerkok.pokkit.player;