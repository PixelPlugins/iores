<?php
	echo "Hi!";
?>