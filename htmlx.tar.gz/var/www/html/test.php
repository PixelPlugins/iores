<html>
	<script>
		document.write("HI");
		
		setInterval(x, 1000);
		
		function x(){
			console.log("hi");
		}
	</script>
</html>