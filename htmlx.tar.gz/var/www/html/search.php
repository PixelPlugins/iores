<?php
	echo file_get_contents("http://192.168.1.3/search.php?q=" . $_GET['q'] . "&maxresults=" . $_GET['maxresults']);
?>