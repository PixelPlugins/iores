<?php
	if($_GET['rw'] == "read"){
		$myfile = fopen("files/".$_GET['filename'], 'r') or die("Unable to open file!");
		echo fread($myfile, filesize($_GET['filename']));
		fclose($myfile);
	}else if($_GET['rw'] == "write"){
		$myfile = fopen("files/".$_GET['filename'], "w");
		echo error_get_last()['message'];
		fwrite($myfile, $_GET['content']);
		fclose($myfile);
	}else if($_GET['rw'] == "append"){
		$myfile = fopen("files/".$_GET['filename'], "a");
		echo error_get_last()['message'];
		fwrite($myfile, $_GET['content']);
		fclose($myfile);
	}
?>